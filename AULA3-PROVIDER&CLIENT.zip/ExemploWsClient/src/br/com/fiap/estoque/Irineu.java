package br.com.fiap.estoque;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import br.com.fiap.estoque.EstoqueBasicoStub.Soma;
import br.com.fiap.estoque.EstoqueBasicoStub.SomaResponse;

public class Irineu {
	
	public static void main(String[] args) {
		
		try {
			EstoqueBasicoStub ebs=new EstoqueBasicoStub();
			
			Soma sm=new Soma();
			sm.setNr1(1);
			sm.setNr2(2);
			
			SomaResponse smr= ebs.soma(sm);
			
			System.out.println(smr.get_return());
		} catch (AxisFault e) {
			e.printStackTrace();
			
		}catch(RemoteException e2) {
			e2.printStackTrace();
		}
	}

}
