package br.com.fiap.estoque;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import br.com.fiap.estoque.EstoqueBasicoStub.Produto;
import br.com.fiap.estoque.EstoqueBasicoStub.ProdutoResponse;



public class Teste {

	public static void main(String[] args) throws AxisFault {
		try {
			EstoqueBasicoStub ebs=new EstoqueBasicoStub();
			
			Produto p=new Produto();
			p.setCod(2);
			ProdutoResponse response=ebs.produto(p);
			System.out.println(response.get_return());
			
			
			
		} catch (AxisFault e) {
			e.printStackTrace();
			
		}catch(RemoteException e2) {
			e2.printStackTrace();
		}
	}
}
