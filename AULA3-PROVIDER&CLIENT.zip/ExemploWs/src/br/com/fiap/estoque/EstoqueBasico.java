package br.com.fiap.estoque;

public class EstoqueBasico {
	//classe de servico
	//soapUI faz os testes 
	public int soma(int nr1, int nr2) {
		return (nr1+nr2);
	}
	
	public String produto(int cod) {
		String a=null;
		if(cod==1) {
			return a="Produto 1";
		}else {
			if(cod==2) 
				return a="Produto 2";
		}
		return a;
	
	}
	
	

}
